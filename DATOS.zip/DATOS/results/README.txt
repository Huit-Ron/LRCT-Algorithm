This dataset contains the raw and processed values used to generate the figures and tables in the manuscript. Each .txt file includes tabulated parameters and error metrics obtained during image analysis.
Variables included:
- ESCALA: Scale factor applied (unitless).
- CANAL: Color channel used for analysis (e.g., yyiq,rrgb,grgb,etc).
- POTENCIA: Power parameter applied in the algorithm, p=0.5,1,2,3, etc.
- BORDES: Edge detection method used (e.g., s = Sobel, p=prewitt, g=gradient).
- Distancia de búsqueda: d_b Search distance parameter (pixels).
- Tamaño de región: T Region size considered (pixels).
- Tiempo SCRL: Processing time for LRCT method (seconds).
- Tiempo Canny: Processing time for Canny-Moore methods (seconds).
- Puntos SCRL: Number of points detected with LRCT.
- Puntos Canny: Number of points detected with Canny-Moore.
- RMSE: Root Mean Square Error (pixels).
- MAE: Mean Absolute Error (pixels).
- Max Error: Maximum error observed (pixels).
