function f4=sdc_f04_bordes(f2,tipo)

[fil2,col2]=size(f2);
f2=double(f2);
f3=zeros(fil2,col2);
switch(tipo)
    case 'g'
            for i=2:fil2-1
                for j=2:col2-1
                    Gx=(f2(i,j+1)-f2(i,j-1))/2;
                    Gy=(f2(i+1,j)-f2(i-1,j))/2;
                    f3(i,j)=sqrt(Gx^2+Gy^2);
                end
            end
    case 's'
        Sx=[-1 0 1;-2 0 2;-1 0 1];
        Sy=[-1 -2 -1;0 0 0;1 2 1];
            for i=2:fil2-1
                for j=2:col2-1
                    Gx=sum(sum(Sx.*(f2(i-1:i+1,j-1:j+1))));
                    Gy=sum(sum(Sy.*(f2(i-1:i+1,j-1:j+1))));
                    f3(i,j)=sqrt(Gx^2+Gy^2);
                end
            end
      case 'p'
        Px=[-1 0 1;-1 0 1;-1 0 1];
        Py=[-1 -1 -1;0 0 0;1 1 1];
            for i=2:fil2-1
                for j=2:col2-1
                    Gx=sum(sum(Px.*(f2(i-1:i+1,j-1:j+1))));
                    Gy=sum(sum(Py.*(f2(i-1:i+1,j-1:j+1))));
                    f3(i,j)=sqrt(Gx^2+Gy^2);
                end
            end
    otherwise
        f3=zeros(fil2,col2);
    end

f4=uint8(f3);
end