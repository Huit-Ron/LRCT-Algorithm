function f4=sdc_f10_filtros(f3,TIPO,TF)
[filas,columnas]=size(f3);
f4=ones(size(f3));
f3=double(f3);
switch(TIPO)
    case 'neu'
        f4=f3;
    case 'prom'
        FILTRO=(1/(TF^2)*ones(TF)); 
        for i=(TF+1)/2:filas-(TF-1)/2
            for j=(TF+1)/2:columnas-(TF-1)/2
                V=f3(i-(TF-1)/2:i+(TF-1)/2,j-(TF-1)/2:j+(TF-1)/2);
                f4(i,j)=sum(sum(FILTRO.*V));
            end
        end
     case 'bin'
        f=TF-1;
        for p=0:TF-1
        fila(p+1)=nchoosek(f, p);
        end
        FILTRO=(fila'*fila)./sum(sum(fila'*fila));
        for i=(TF+1)/2:filas-(TF-1)/2
            for j=(TF+1)/2:columnas-(TF-1)/2
                V=f3(i-(TF-1)/2:i+(TF-1)/2,j-(TF-1)/2:j+(TF-1)/2);
                f4(i,j)=sum(sum(FILTRO.*V));
            end
        end
    case 'med'
        for i=(TF+1)/2:filas-(TF-1)/2
            for j=(TF+1)/2:columnas-(TF-1)/2
                V=f3(i-(TF-1)/2:i+(TF-1)/2,j-(TF-1)/2:j+(TF-1)/2);
                f4(i,j)=median(V,"all");
            end
        end
    otherwise
       f4=zeros(size(f3));
end
f4=uint8(f4);
