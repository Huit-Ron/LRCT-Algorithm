function f4=overlay_dlr_f01_ventana(f4,T,xc,yc,r,g,b)
LL=(T-1)/2;
[fil4,col4,cap4]=size(f4);
Ls=yc-LL;
Li=yc+LL;
Liz=xc-LL;
Lde=xc+LL;

if Ls<=1
    Ls=1;
end
if Liz<=1
    Liz=1;
end
if Li>=fil4
    Li=fil4;
end
if Lde>=col4
    Lde=col4;
end

f4(Ls,Liz:Lde,1)=r;
f4(Ls,Liz:Lde,2)=g;
f4(Ls,Liz:Lde,3)=b;


f4(Li,Liz:Lde,1)=r;
f4(Li,Liz:Lde,2)=g;
f4(Li,Liz:Lde,3)=b;

f4(Ls:Li,Liz,1)=r;
f4(Ls:Li,Liz,2)=g;
f4(Ls:Li,Liz,3)=b;

f4(Ls:Li,Lde,1)=r;
f4(Ls:Li,Lde,2)=g;
f4(Ls:Li,Lde,3)=b;

end