function f2=sdc_f01_nivelgris(f1,capa)
%Obtiene la capa de gris señalada
switch(capa)
    case 'rrgb'
        f2=f1(:,:,1);
    case 'grgb'
        f2=f1(:,:,2);
    case 'brgb' 
        f2=f1(:,:,3);
    case 'yyiq'
        f1=double(f1);
        f2=uint8(0.299*f1(:,:,1)+0.587*f1(:,:,2)+0.114*f1(:,:,3));
     case 'iyiq'
        f1=double(f1);
        f2=uint8(0.596*f1(:,:,1)-.275*f1(:,:,2)-0.321*f1(:,:,3));
     case 'qyiq'
        f1=double(f1);
        f2=uint8(0.212*f1(:,:,1)-.523*f1(:,:,2)+0.311*f1(:,:,3));
    case 'hhsv'
        HSV=rgb2hsv(f1);
        f2=uint8(255*HSV(:,:,1));
    case 'shsv'
        HSV=rgb2hsv(f1);
        f2=uint8(255*HSV(:,:,2));
    case 'vhsv'
        HSV=rgb2hsv(f1);
        f2=uint8(255*HSV(:,:,3));
    case 'ccmy'
        f2=255-f1(:,:,1);
    case 'mcmy'
        f2=255-f1(:,:,2);
    case 'ycmy'
        f2=255-f1(:,:,3);
    otherwise
        [fil1,col1]=size(f1);
        f2=uint8(zeros(fil1,col1));
end
end