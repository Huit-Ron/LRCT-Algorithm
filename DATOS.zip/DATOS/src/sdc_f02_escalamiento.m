function f1=sdc_f02_escalamiento(f0,S,M)

[filasi,columnasi]=size(f0);
filasf=round(S*filasi);
columnasf=round(S*columnasi);
f1=uint8(zeros(filasf,columnasf));

switch M
    case 'M'
            for i=1:filasf
                for j=1:columnasf
                    f1(i,j)=f0(round(i/S),round(j/S));
                end
            end
    case 'P'
            for i=1:filasf
                for j=1:columnasf
                    if j<columnasf&&i<filasf
                    A=f0(round(i/S):round((i/S)+1/S-1),round(j/S):round((j/S)+1/S-1),:);
                    f1(i,j,:)=mean(A(:));
                    elseif j<columnasf&&i==filasf
                    A=f0(round(i/S):end,round(j/S):round((j/S)+1/S-1),:);
                    f1(i,j,:)=mean(A(:)); 
                    elseif j==columnasf&&i<filasf
                    A=f0(round(i/S):round((i/S)+1/S-1),round(j/S):end,:);
                    f1(i,j,:)=mean(A(:));
                    end

                end
            end

    otherwise
        f1=f0;
end
end