function fo=dlr_f03_corrim(fi,p)
x=0:255;
y=255*(x.^p)/(255^p);
fo=zeros(size(fi));

[filas,columnas]=size(fi);
for j=1:filas
    for i=1:columnas
        fo(j,i)=y(1,fi(j,i)+1)-1;
    end
end
fo=uint8(fo);
end