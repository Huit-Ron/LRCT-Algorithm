function [X,Y,theta,rho,r]=sdc_f05_descriptor_ventana(f4,T,x,y,sig)

[X,Y,r]=sdc_a_02_vectores(f4,T,x,y,sig);

if r==1
FIN=1;
while FIN
    [theta,rho,X,Y,FIN]=sdc_a_03_lmsGrl(X,Y);
end
else
    theta=0;rho=0;
end
end