clc
clear all
close all

f0=imread("imagenes\1.jpg");
f1=sdc_f01_nivelgris(f0,'rrgb');
f2=sdc_f02_escalamiento(f1,0.1,'P');[fil,col]=size(f2);
f3=sdc_f03_corrim(f2,3);
f4=sdc_f04_bordes(f3,'s');
[H,sig]=sdc_a_01_histograma(f4);
f5=zeros(size(f4));
T=11;
db=3;
[x,y,data]=impixel(f4);
xi=x;yi=y;
[X,Y,theta,rho,r]=sdc_f05_descriptor_ventana(f4,T,x,y,sig);
[px,py]=sdc_f06_busqueda_inicial(theta,rho,x,y,2,db);
l=2;fin=1;
while fin
    [X,Y,theta,rho,r]=sdc_f05_descriptor_ventana(f4,T,x,y,sig);
    [xb,yb,x,y]=sdc_f07_busqueda_continua(theta,rho,x,y,db,px,py);
    px(end+1)=x;py(end+1)=y;
    x=xb;y=yb;
    fin=sdc_f08_fin_busqueda(db,px,py,fil,col);
end
px(end+1)=px(1);py(end+1)=py(1);
figure,plot(px,py,'o-r')
axis([1 fil 1 col]), axis image, set(gca, 'YDir', 'reverse'),xlabel('Contour X-coordinate'),ylabel('Contour Y-coordinate')
%nombre=strcat("out\\f13_01_db",num2str(db),"T_",num2str(T),"l_",num2str(length(px)),".jpg");
nombre=strcat("out 600dpi\\f13_01_db",num2str(db),"T_",num2str(T),"l_",num2str(length(px)),".jpg");
%saveas(gcf,nombre)
%exportgraphics(gcf, nombre, "Resolution", 600)