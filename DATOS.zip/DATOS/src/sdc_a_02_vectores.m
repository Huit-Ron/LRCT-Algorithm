function [X,Y,r,V]=sdc_a_02_vectores(f3,T,xc,yc,sig)
[filas,columnas]=size(f3);
V=uint8(zeros(T));
if xc-(T-1)/2<1
    Lsx=1;
    Lix=xc+(T-1)/2;
    ix=T-Lix;
elseif xc+(T-1)/2>columnas
    Lsx=xc-(T-1)/2;
    Lix=columnas;
    ix=1;
else
    Lsx=xc-(T-1)/2;
    Lix=xc+(T-1)/2;
    ix=1;
end

if (yc-(T-1)/2)<1
    Lsy=1;
    Liy=yc+(T-1)/2;
    iy=T-Liy;
elseif (yc+(T-1)/2)>filas
    Lsy=yc-(T-1)/2;
    Liy=filas;
    iy=1;
else
    Lsy=yc-(T-1)/2;
    Liy=yc+(T-1)/2;
    iy=1;
end
S=f3(Lsy:Liy,Lsx:Lix);
[Tf,Tc]=size(S);
V(iy:iy+Tf-1,ix:ix+Tc-1)=S;

[fil,col]=size(V);

X=[];
Y=[];
n=0;
r=0;
for j=1:fil
    for i=1:col
        if V(j, i)>3*sig
            n=n+1;
            X(n) = i;
            Y(n) = j;
            r=1;
        end
    end
end

X=X-(T/2)+xc;
Y=Y-(T/2)+yc;
end