function [xb,yb,xv,yv]=sdc_f07_busqueda_continua(thetaf,rhof,xc,yc,db,px,py)
%theta2=atan(-1/tan(thetaf));
theta2=thetaf+pi/2;%%
rho2=xc*cos(theta2)+yc*sin(theta2);
xv=(rhof*sin(theta2)-rho2*sin(thetaf))/(sin(theta2)*cos(thetaf)-sin(thetaf)*cos(theta2));
yv=(rhof-xv*cos(thetaf))/sin(thetaf);

xb1=xv-db*sin(thetaf);
yb1=yv+db*cos(thetaf);
xb2=xv+db*sin(thetaf);
yb2=yv-db*cos(thetaf);

xa=px(end-1);
ya=py(end-1);

d1=sqrt((xa-xb1)^2+(ya-yb1)^2);
d2=sqrt((xa-xb2)^2+(ya-yb2)^2);

if d1>=d2
    xb=xb1;yb=yb1;
else
    xb=xb2;yb=yb2;
end

end