function [px,py]=sdc_f06_busqueda_inicial(thetaf,rhof,xc,yc,DIR,db)
theta2=atan(-1/tan(thetaf));
rho2=xc*cos(theta2)+yc*sin(theta2);
xv=(rhof*sin(theta2)-rho2*sin(thetaf))/(sin(theta2)*cos(thetaf)-sin(thetaf)*cos(theta2));
yv=(rhof-xv*cos(thetaf))/sin(thetaf);
if DIR==1
xb=xv-db*sin(thetaf);
yb=yv+db*cos(thetaf);
else
xb=xv+db*sin(thetaf);
yb=yv-db*cos(thetaf);
end

px=[xb xv];
py=[yb yv];
end