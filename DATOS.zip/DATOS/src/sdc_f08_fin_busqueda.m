function fin=sdc_f08_fin_busqueda(db,px,py,fil,col)
desborde=px(end)<=0||px(end)>col||py(end)<0||py(end)>fil||length(px)>=(2*fil+2*col)/db;
if sqrt((px(end)-px(1))^2+(py(end)-py(1))^2)<db||desborde
    if length(px)>3
       fin=0;
    else
        fin=1;
    end
    else
       fin=1;
end
end