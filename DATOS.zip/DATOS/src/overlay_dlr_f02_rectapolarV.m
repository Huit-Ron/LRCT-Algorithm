function f4=overlay_dlr_f02_rectapolarV(f4,rho,theta,xmin,xmax,ymin,ymax,r,g,b)

[fil4,col4,cap4]=size(f4);
xg=xmin:0.1:xmax;
%yg=-xg*cot(theta)+rho/sin(theta);
yg=(rho-xg*cos(theta))/sin(theta);
for l=1:length(xg)
    if yg(l)>=1&&yg(l)<=fil4&&yg(l)>=ymin&&yg(l)<=ymax
        f4(uint16(yg(l)),uint16(xg(l)),1)=r;
        f4(uint16(yg(l)),uint16(xg(l)),2)=g;
        f4(uint16(yg(l)),uint16(xg(l)),3)=b;
    end
end