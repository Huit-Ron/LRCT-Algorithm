function [thetaf,rhof,xp,yp,FIN]=sdc_a_03_lmsGrl_rectas(xp,yp)

A=[xp' ones(length(xp),1)];
B=yp';
S=(A'*A)\(A'*B);
theta1=atan(-1/S(1,1));
rho1=S(2,1)*sin(theta1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear A B S
xpr=-yp;
ypr=xp;
A=[xpr' ones(length(xpr),1)];
B=ypr';
S=(A'*A)\(A'*B);
theta2=atan(-1/S(1,1));
rho2=S(2,1)*sin(theta2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y1=(rho1-xp*cos(theta1))/sin(theta1);
y2=(rho2-xpr*cos(theta2))/sin(theta2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
R_2_1=1-(sum((yp-y1).^2)/sum((yp-mean(yp)).^2));
R_2_2=1-(sum((ypr-y2).^2)/sum((ypr-mean(ypr)).^2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if R_2_2<=R_2_1
    thetaf=theta1;
    rhof=rho1;
    R_2=R_2_1;
else
    thetaf=theta2-pi/2;
    rhof=rho2;
    R_2=R_2_2;
end

%%%%%%%%%%%%%%%%%%%%%%
% thetaf = mod(thetaf, 2*pi);
% 
% if rhof < 0
%     rhof = -rhof;
%     thetaf = mod(thetaf + pi, 2*pi);
% end
% 
% if thetaf >= pi
%     thetaf = thetaf - pi;
%     rhof = -rhof;
% end

d=abs(xp.*cos(thetaf)+yp.*sin(thetaf)-rhof);
[v,p]=max(d);
if v>2
    xp(p)=[];
    yp(p)=[];
    FIN=1;
else
    FIN=0;
end
end
