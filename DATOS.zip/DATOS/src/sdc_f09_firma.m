function d=sdc_f09_firma(px,py)

% for l=1:length(px)
%     do(l)=sqrt((px(l)-1)^2+(py(l)-1)^2);
% end
% [vm,pm]=min(do);
% 
% px=circshift(px, pm);
% py=circshift(py, pm);

cx=mean(px);
cy=mean(py);

for l=1:length(px)
    d(l)=sqrt((cx-px(l))^2+(cy-py(l))^2);
end

[vM,pM]=max(d);

px=circshift(px, -pM + 1);
py=circshift(py, -pM + 1);