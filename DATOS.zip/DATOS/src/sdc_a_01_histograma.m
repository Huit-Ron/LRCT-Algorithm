function [H,sig]=sdc_a_01_histograma(f0)
[f,c]=size(f0);
H = zeros(1, 256); % Initialize histogram array for 256 intensity levels
for i = 1:f
    for j = 1:c
        H(f0(i,j) + 1) = H(f0(i,j) + 1) + 1; % Increment histogram count for each intensity level
    end
end

u=sum([0:255].*H)/sum(H);
sig=sqrt(sum(H.*(([0:255]-u).^2))/sum(H));